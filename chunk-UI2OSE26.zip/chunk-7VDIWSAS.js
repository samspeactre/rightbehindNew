import{a}from"./chunk-RUUYYATM.js";import"./chunk-N6BL4XIM.js";import"./chunk-5JE6BRW4.js";import"./chunk-QVJ4LEGS.js";import"./chunk-DM275RSA.js";export{a as FooterComponent};
